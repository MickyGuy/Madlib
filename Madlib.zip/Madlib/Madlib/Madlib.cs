﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Madlib
{
    class Madlib
    {
        static void Main(string[] args)
        {
            Console.WriteLine("-------");
            Console.WriteLine("Madlib!");
            Console.WriteLine("-------");

            string creature;
            string luminous;
            string ghastly;
            string spectral;
            string countryman;
            string farrier;
            string farmer;
            string dreadful;
            string apparition;
            string hound;
            string story;

            Console.Write("Please Enter a Creature: ");
            creature = Console.ReadLine();
            Console.Write("\nPlease Enter a Evil Description: ");
            luminous = Console.ReadLine();
            Console.Write("\nPlease Enter a Evil Description: ");
            ghastly = Console.ReadLine();
            Console.Write("\nPlease Enter a Evil Description: ");
            spectral = Console.ReadLine();
            Console.Write("\nPlease Enter a Hero: ");
            countryman = Console.ReadLine();
            Console.Write("\nPlease Enter a Hero: ");
            farrier = Console.ReadLine();
            Console.Write("\nPlease Enter a Hero: ");
            farmer = Console.ReadLine();
            Console.Write("\nPlease Enter a Evil Description: ");
            dreadful = Console.ReadLine();
            Console.Write("\nPlease Enter a Occupation: ");
            apparition = Console.ReadLine();
            Console.Write("\nPlease Enter a Item: ");
            hound = Console.ReadLine();
            //Console.Write("\nPlease Enter a Noun: ");
            //story = Console.ReadLine();
           

            story = "\nThe " + creature + " a " + luminous + ", " + ghastly + ", " + spectral + " thing. I have looked for people, people that can take it down. One, a hard-headed " + countryman + ", the other a " + farrier + ", and a " + farmer + " with many skills, who all are able to take down this " + dreadful + " " + apparition + " " + creature + ", to find the " + hound + " of legend.";
            Console.WriteLine(story);

            Console.ReadLine();
            Console.WriteLine("Press enter to exit");
            Console.ReadKey();
        }
    }
}
